Integrates Cognigy.AI with Lekab (https://www.lekab.com)

Connection
This Extension needs a Connection to be defined and passed to the Nodes. The Connection must have the following keys:

APIkey
(you can create APIkey https://app.lekab.com )

Node: sendSMS

You need the from Sender SMS Number, the to Recipient SMS Number and the to SMS content (max. 1600 characters).